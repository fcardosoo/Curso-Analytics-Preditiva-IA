

select  
	account_id,
	occurred_at,
	total
from 
	preditiva.db_parchnposey.orders


-- ***************************
-- Exemplos de particionamento:
-- ***************************	
	
	
-- Retorna a data e valor do maior pedido por conta de usuário

-- Solução 1

with passo1 as (
	select  
		account_id,
		FIRST_VALUE(total) OVER (PARTITION by account_id ORDER by total desc ) as Qte,
		FIRST_VALUE(occurred_at) OVER (PARTITION by account_id ORDER by total desc ) as Data_Pedido
	from 
		preditiva.db_parchnposey.orders

)

select DISTINCT 
	account_id,
	Data_Pedido,
	Qte as Qte_Primeiro_Maior_Pedido
from
	passo1

	
-- Solução 2
with passo1 as (
	select  
		account_id,
		total as Qte,
		ROW_NUMBER() OVER (PARTITION by account_id ORDER by total desc ) as Linha,
		FIRST_VALUE(occurred_at) OVER (PARTITION by account_id ORDER by total desc ) as Data_Pedido
	from 
		preditiva.db_parchnposey.orders
)

select 
	account_id,
	Data_Pedido,
	Qte as Qte_Primeiro_Maior_Pedido
from
	passo1
where
	Linha = 1
	
	
	
-- Se precisar de mais controle da ordenação, pode-se usar a função DENSE_RANK()
	
with passo1 as (
	select  
		account_id,
		occurred_at as Data_Pedido,
		total as Qte,
		DENSE_RANK() OVER (PARTITION by account_id ORDER by total desc ) as TOP_Qte_por_AccountID
	from 
		preditiva.db_parchnposey.orders

)

select  
	account_id,
	Data_Pedido,
	Qte as Qte_Segundo_Maior_Pedido
from
	passo1
where
	TOP_Qte_por_AccountID = 2
	


-- Média Móvel com o uso de particionamento (ordenado por data crescente) 

	with passo1 as (
	select 
		CAST(occurred_at as date) as data_pedido,
		sum(total) as qte_vendida
	from 
		preditiva.db_parchnposey.orders
	group by
		CAST(occurred_at as date)	
)

select 
	data_pedido,
	qte_vendida,
	avg(qte_vendida) OVER (	ORDER by data_pedido 
							ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) as media_movel_7dias
from
	passo1
	
	
	
-- Média Móvel com o uso de particionamento (ordenado por data decrescente) 


with passo1 as (
	select 
		CAST(occurred_at as date) as data_pedido,
		sum(total) as qte_vendida
	from 
		preditiva.db_parchnposey.orders
	group by
		CAST(occurred_at as date)	
)

select 
	data_pedido,
	qte_vendida,
	avg(qte_vendida) OVER (	ORDER by data_pedido DESC 
							ROWS BETWEEN CURRENT ROW AND 6 FOLLOWING) as media_movel_7dias
from
	passo1
	
	
	

-- É muito comum a confusão do RANK, DENSE_RANK e ROW Number. Veja diferença:

WITH Tabela (ID, QTE)
     AS (SELECT 1,10 UNION ALL
         SELECT 1,10 UNION ALL
         SELECT 1,10 UNION ALL
         SELECT 1,20)
SELECT *,
       ROW_NUMBER() OVER(PARTITION BY ID ORDER BY QTE) AS 'ROW_NUMBER',
       RANK() OVER(PARTITION BY ID ORDER BY QTE)       AS 'RANK',
       DENSE_RANK() OVER(PARTITION BY ID ORDER BY QTE) AS 'DENSE_RANK'
FROM
	Tabela 
	
	
	
	
	
	